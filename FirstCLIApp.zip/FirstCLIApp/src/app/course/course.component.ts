import { Component, OnInit, Input, OnChanges, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
})
export class CourseComponent implements OnInit,OnChanges {

  @Input('name') coursename:string="";
  constructor() {
        console.log(`Within Constructor ! Name : ${this.coursename} ` );
   }
   ngOnChanges(changes:SimpleChanges){
    console.log(`Within ngOnChanges ! Name : ${this.coursename}`);  
    
    for(let prop in changes){
      console.log(`Property name: ${prop} , Current Value : ${changes[prop].currentValue}, Previous Value : ${changes[prop].previousValue}`)
    }    
   }
  ngOnInit() {
    console.log(`Within ngOnInit ! Name : ${this.coursename}`);
  }

}
