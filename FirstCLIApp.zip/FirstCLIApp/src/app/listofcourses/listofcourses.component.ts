import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listofcourses',
  templateUrl: './listofcourses.component.html',
  styleUrls: ['./listofcourses.component.css']
})
export class ListofcoursesComponent implements OnInit {

  isChecked:boolean=true;
  courses:string[]=[];
  //newcourse:string="";

  constructor() { }

  ngOnInit() {
  }

}
