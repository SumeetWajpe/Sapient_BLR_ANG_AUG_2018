import {Component} from '@angular/core';
import {CourseService} from './course.service';

@Component({
        selector:`usecourseserv`,
        template:`
        <div style="width:500px;border:2px solid red;border-radius:10px;padding:20px;margin:20px;">
        <h1> List Of Courses </h1>
        New Course : <input type="text" class="form-control" [(ngModel)]="courseToBeAdded" /> {{courseReceived}} <br/>
        <input type="button" (click)="AddCourse()" value="Add Course >>" class="btn btn-primary" />
        <input type="button" (click)="GetCourse()" value="Get Random Course" class="btn btn-primary" />    
        </div>`
        ,providers:[CourseService]
})

export class UseCourseServComponent{

    courseToBeAdded:string="";
    courseReceived:string="";
    
    constructor(public servObj:CourseService){
     
    }

    AddCourse(){
        this.servObj.addNewCourse(this.courseToBeAdded);
    }
    GetCourse(){
        this.courseReceived = this.servObj.getRandomCourse();
    }

}