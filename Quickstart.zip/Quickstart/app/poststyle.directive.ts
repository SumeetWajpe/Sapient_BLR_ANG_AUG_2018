import {Directive, 
    ElementRef, 
    OnInit, 
    Input, HostListener
} from '@angular/core';

@Directive({
    selector:`[poststyle]`
    
})
export class PostStyleDirective implements OnInit{

    @Input('postColor')   passedColor:string = "lightgreen";
    constructor(private refElement:ElementRef){
    }
    ngOnInit(){
        this.refElement.nativeElement.style.backgroundColor = this.passedColor;
        this.refElement.nativeElement.style.border = '2px solid red';
        this.refElement.nativeElement.style.borderRadius = '10px';
        
        this.refElement.nativeElement.style.padding = '10px';
        this.refElement.nativeElement.style.margin = '10px';
    }

   @HostListener('mouseenter') OnMouseEnter(){
        this.refElement.nativeElement.style.backgroundColor = "orange";
    }

    @HostListener('mouseleave') OnMouseLeave(){
        this.refElement.nativeElement.style.backgroundColor = this.passedColor;
        

    }


}