"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var CourseComponent = (function () {
    function CourseComponent() {
        this.isSuccess = true;
        this.companyName = "JCI";
        this.coursedetails = { name: "Angular",
            duration: '3 Days', price: 2000, rating: 2 };
    }
    CourseComponent.prototype.ChangeHeading = function (evt) {
        //??
        this.companyName = (evt.target.value);
    };
    return CourseComponent;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", Object)
], CourseComponent.prototype, "coursedetails", void 0);
CourseComponent = __decorate([
    core_1.Component({
        selector: 'course',
        template: "\n\n        <!--\n        <h1>{{companyName}}</h1>\n      Company Name : <input type=\"text\"\n         [value]=\"companyName\"\n         (input)=\"ChangeHeading($event)\"\n          /> \n\n          Company Name : <input type=\"text\"\n           [(ngModel)]=\"companyName\" />\n\n           <br/>\n\n           Is Success : <input type=\"checkbox\"\n            [(ngModel)]=\"isSuccess\"\n           />\n\n        \n        <input type=\"button\" value=\"Styled Button\"\n        [style.backgroundColor]=\"isSuccess ? 'green' : 'red' \" />\n        \n        -->\n\n\n        \n\n        <h1> {{coursedetails.name | uppercase | lowercase }}  </h1>\n        <img [src]=\"coursedetails.imageurl\" height=\"200\" width=\"200\" /><br/>\n        \n        \n          <b>Duration : </b> {{coursedetails.duration | duration:'months' }} <br/>\n        <b>Price : </b> {{coursedetails.price | currency:'INR':true }} <br/>\n        <b>Rating : </b> {{coursedetails.rating | number:'1.1-2' }} <br/>\n       <!-- <b> raw Data : </b> {{ coursedetails | json }} -->\n        "
    })
], CourseComponent);
exports.CourseComponent = CourseComponent;
//# sourceMappingURL=courses.component.js.map