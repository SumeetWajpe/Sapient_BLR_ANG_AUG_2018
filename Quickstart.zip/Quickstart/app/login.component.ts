
import { Component } from "@angular/core";
import { UserService } from "./user.service";
import { Router } from "@angular/router";

@Component({
        selector:'login',
        template:`

        <form (ngSubmit)="HandleFormSubmit()">


        Username : <input type="text" 
        name="name" class="form-control" [(ngModel)]="inputName" /> 
        Password : <input type="text" 
        name="password" class="form-control" [(ngModel)]="inputPassword" /> 
        

        <input type="submit"
         value="Sign In" 
         class="btn btn-primary" />
        </form>

        `
        
})
export class LoginComponent{

public inputName:string ="";
public inputPassword:string = "";
    constructor(private userservObj:UserService,private route:Router){

    }

    HandleFormSubmit(){
        if(this.inputName == "admin" && this.inputPassword == "admin"){
            this.userservObj.setUserLoggedIn();
            this.userservObj.username = "admin";
            // navigate to courses
            this.route.navigate(['/dashboard'])
        }
    }

}