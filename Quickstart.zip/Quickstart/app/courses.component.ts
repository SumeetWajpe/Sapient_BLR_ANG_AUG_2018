import { Component ,Input} from "@angular/core";





@Component({
        selector:'course',
        template:`

        <!--
        <h1>{{companyName}}</h1>
      Company Name : <input type="text"
         [value]="companyName"
         (input)="ChangeHeading($event)"
          /> 

          Company Name : <input type="text"
           [(ngModel)]="companyName" />

           <br/>

           Is Success : <input type="checkbox"
            [(ngModel)]="isSuccess"
           />

        
        <input type="button" value="Styled Button"
        [style.backgroundColor]="isSuccess ? 'green' : 'red' " />
        
        -->


        

        <h1> {{coursedetails.name | uppercase | lowercase }}  </h1>
        <img [src]="coursedetails.imageurl" height="200" width="200" /><br/>
        
        
          <b>Duration : </b> {{coursedetails.duration | duration:'months' }} <br/>
        <b>Price : </b> {{coursedetails.price | currency:'INR':true }} <br/>
        <b>Rating : </b> {{coursedetails.rating | number:'1.1-2' }} <br/>
       <!-- <b> raw Data : </b> {{ coursedetails | json }} -->
        `
    })
export class CourseComponent{
    isSuccess:boolean= true;
    companyName:string = "JCI";

   

     @Input()   coursedetails:any={name:"Angular",
     duration:'3 Days',price:2000,rating:2};

     ChangeHeading(evt:any){
         //??

         this.companyName = (evt.target.value);
     }
}