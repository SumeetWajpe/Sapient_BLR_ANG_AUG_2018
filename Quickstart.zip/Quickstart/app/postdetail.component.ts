import {Component, OnInit} from '@angular/core';
import { ActivatedRoute } from '@angular/router';


@Component({
    selector:`post-detail`,
    template:`<h1> Post Details for {{postId}} </h1>
    
   <b>  title : </b> {{thePost.title}} <br/>
   <b>  body : </b> {{thePost.body}} 

    `

})
export class PostDetailComponent implements OnInit{
    private postId:number;
    private thePost:any;
    constructor(private currRoute:ActivatedRoute){        

    }

    ngOnInit(){
        this.currRoute.params.subscribe(
            p => {
                this.postId = p['id'];
                var allPosts = JSON.parse(localStorage['posts']);
                
                var theIndex = allPosts.findIndex( 
                    (currPost:any) => currPost.id == this.postId 
                );

                this.thePost = allPosts[theIndex];
            } 
)
    }

}