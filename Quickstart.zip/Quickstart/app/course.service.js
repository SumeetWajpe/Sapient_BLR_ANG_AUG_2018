"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var CourseService = (function () {
    function CourseService() {
        this.listOfCourses = ['React', 'Node', 'Angular'];
    }
    CourseService.prototype.getRandomCourse = function () {
        return this.listOfCourses[Math.floor(Math.random() * this.listOfCourses.length)];
    };
    CourseService.prototype.getAllCourses = function () {
        return this.listOfCourses;
    };
    CourseService.prototype.addNewCourse = function (newCourse) {
        this.listOfCourses.push(newCourse);
    };
    return CourseService;
}());
exports.CourseService = CourseService;
//# sourceMappingURL=course.service.js.map