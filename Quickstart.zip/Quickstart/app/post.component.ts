import {Component, APP_BOOTSTRAP_LISTENER} from '@angular/core';
import { PostsService } from './posts.service';

@Component({
        selector:`posts`,
        template:`

        <h1> All Posts ! </h1>

       

        <ul >
        <li *ngFor="let post of allPosts" poststyle postColor="lightblue" >
        <a [routerLink]="['/post',post.id]"> {{post.title}}  </a>
        </li>
        <ul>

    `
        ,providers:[PostsService]
})

export class PostsComponent{    
    // constructor(private servObj:PostsService){
    //  this.servObj.getPosts(function(respFromService:any){        
    //     console.log('Within Component !');
    //     console.log(respFromService)
    //  });
    // }

    allPosts:any[] = [];

    constructor(private servObj:PostsService){
      let aPromise =  this.servObj.getPosts();
      aPromise.then(
          (responseFromService)=>{
                console.log('Promise resolved !');
                this.allPosts = responseFromService.json();
                localStorage['posts'] = JSON.stringify(this.allPosts);
          },(err)=> {
                console.log('Promise rejected !');
                console.log(err);
          }
      )
       }

}